package com.example.recardo

// Activity3.kt
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Calendar

class Activity3 : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var profilePicImageView: ImageView
    private lateinit var participantNameTextView: TextView
    private lateinit var transactionHistoryLayout: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_3)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("TransactionHistory", Context.MODE_PRIVATE)

        // Initialize views
        profilePicImageView = findViewById(R.id.profilePicImageView)
        participantNameTextView = findViewById(R.id.participantNameTextView)
        transactionHistoryLayout = findViewById(R.id.transactionHistoryLayout)


        // Retrieve participant's name and profile picture from intent extras
        val participantName = intent.getStringExtra("participantName")
        val profilePicByteArray = intent.getByteArrayExtra("participantProfilePic")

        //val profilePic = intent.getParcelableExtra<Bitmap>("participantProfilePic")

        // Set participant's name and profile picture
        participantNameTextView.text = participantName
       // profilePicImageView.setImageBitmap(profilePic)
        if (profilePicByteArray != null) {
            // Convert the byte array back to a Bitmap
            val profilePic = profilePicByteArray.toBitmap()

            // Now you can use the profilePic Bitmap as needed
            profilePicImageView.setImageBitmap(profilePic)
        } else {
            profilePicImageView.setImageResource(R.drawable.ic_default_profile_pic)

            // Handle the case where no profile pic was passed
            // For example, set a default image or show an error message
        }

        // Load and display transaction history for the selected participant
        loadTransactionHistory(participantName)

        /// To Display the current date
        // Find the TextView by its ID
        val dateTextView: TextView = findViewById(R.id.dateTextView)

        // Get current date
        val currentDate = getCurrentDate()

        // Define date format
        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())

        // Format the current date
        val formattedDate: String = dateFormat.format(currentDate.time)

        // Set the formatted date to the TextView
        dateTextView.text = formattedDate

    }
    private fun getCurrentDate(): Calendar {
        return Calendar.getInstance()
    }

    private fun loadTransactionHistory(participantName: String?) {
        participantName?.let { name ->
            val transactionKey = "transactionHistory_$name"
            val transactionHistoryJson = sharedPreferences.getString(transactionKey, "")

            if (!transactionHistoryJson.isNullOrEmpty()) {
                val transactions = Gson().fromJson(transactionHistoryJson, Array<Transaction>::class.java)
                displayTransactionHistory(transactions.toList())
            }
        }
    }

    private fun displayTransactionHistory(transactions: List<Transaction>) {
        for (transaction in transactions) {
            val transactionView = layoutInflater.inflate(R.layout.transaction_item, null)
            val amountLabelTextView = transactionView.findViewById<TextView>(R.id.amountLabelTextView)///////1
            val amountTextView: TextView = transactionView.findViewById(R.id.amountTextView)
            val noteLabelTextView = transactionView.findViewById<TextView>(R.id.noteLabelTextView)//////////2
            val noteTextView: TextView = transactionView.findViewById(R.id.noteTextView)
            val timestampTextView: TextView = transactionView.findViewById(R.id.timestampTextView)
            ////

// Assuming you have a Transaction object named transaction containing the timestamp
            val timestamp = transaction.timestamp
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
            val formattedDate = dateFormat.format(Date(timestamp))

// Set the formatted date to the TextView
            timestampTextView.text = formattedDate
            ////


            // Set transaction details
            amountTextView.text = transaction.amount.toString()
            noteTextView.text = transaction.note
           // timestampTextView.text = transaction.timestamp.toString()

            // Set text color based on transaction type (debit or credit)
            if (transaction.transactionType == "Debit") {
                amountTextView.setTextColor(resources.getColor(android.R.color.holo_red_dark))
            } else {
                amountTextView.setTextColor(resources.getColor(android.R.color.holo_green_dark))
            }

            // Add transaction view to the layout
            transactionHistoryLayout.addView(transactionView)
        }
    }
}
