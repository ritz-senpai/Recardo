package com.example.recardo

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.SharedPreferences

class loginActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val sendOTPButton: Button = findViewById(R.id.sendOTPButton)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("login_pref", Context.MODE_PRIVATE)

        // Check if the user is already logged in
        if (isLoggedIn()) {
            // If already logged in, start MainActivity and finish this activity
            startMainActivity()
            return
        }

        // If not logged in, proceed with login activity logic
        val btnSendOTP: Button = findViewById(R.id.sendOTPButton)
        btnSendOTP.setOnClickListener {
            // Fake sending OTP process for demonstration
            // Proceed to OTP verification activity
            startOTPVerificationActivity()
        }
    }

    private fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean("is_logged_in", false)
    }

    private fun setLoggedIn(isLoggedIn: Boolean) {
        sharedPreferences.edit().putBoolean("is_logged_in", isLoggedIn).apply()
    }

    private fun startMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Close LoginActivity so the user cannot navigate back to it
    }

    private fun startOTPVerificationActivity() {
        val intent = Intent(this, OTPVerificationActivity::class.java)
        startActivity(intent)
    }

    }
