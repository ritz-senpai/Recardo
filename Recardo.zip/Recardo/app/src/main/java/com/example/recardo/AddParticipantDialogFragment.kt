package com.example.recardo

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.fragment.app.DialogFragment

class  AddParticipantDialogFragment : DialogFragment() {

    private lateinit var listener: AddParticipantDialogListener
    private var selectedProfilePic: Bitmap? = null
    private var ivProfilePic: ImageView? = null

    interface AddParticipantDialogListener {
        fun onParticipantAdded(participant: Participant)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.dialog_add_participant, container, false)

        val etParticipantName = view.findViewById<EditText>(R.id.etParticipantName)
        ivProfilePic = view.findViewById(R.id.ivProfilePic) // Assigning the reference here
        val btnAdd = view.findViewById<Button>(R.id.btnAdd)
        val btnCancel = view.findViewById<Button>(R.id.btnCancel)

        ivProfilePic?.setOnClickListener {
            // Open image picker
            openImagePicker()
        }

        btnAdd.setOnClickListener {
            val participantName = etParticipantName.text.toString()
            if (participantName.isNotEmpty()) {
                if (selectedProfilePic != null) {
                    val participant = Participant(participantName, selectedProfilePic)
                    listener.onParticipantAdded(participant)
                    dismiss()
                } else {
                    Toast.makeText(context, "Please select a profile picture", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(context, "Please enter participant name", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancel.setOnClickListener {
            dismiss()
        }

        return view
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_IMAGE_PICKER)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICKER && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                // Convert uri to bitmap
                selectedProfilePic = MediaStore.Images.Media.getBitmap(requireActivity().contentResolver, uri)
                // Display selected image in ImageView
                ivProfilePic?.setImageBitmap(selectedProfilePic)
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            listener = context as AddParticipantDialogListener
        } catch (e: ClassCastException) {
            throw ClassCastException("$context must implement AddParticipantDialogListener")
        }
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        // Reset selected profile picture on dismiss
        selectedProfilePic = null
    }

    companion object {
        private const val REQUEST_IMAGE_PICKER = 100
    }
}
