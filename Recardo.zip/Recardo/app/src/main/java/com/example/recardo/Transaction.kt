package com.example.recardo

data class Transaction(val timestamp: Long, val amount: Float, val note: String , val transactionType: String )
