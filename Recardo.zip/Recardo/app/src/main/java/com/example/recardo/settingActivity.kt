package com.example.recardo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.toBitmap
import java.io.ByteArrayOutputStream
import android.util.Base64

class settingActivity : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var profileImageView: ImageView
    private lateinit var changeProfileButton: Button
    private lateinit var nameEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var backButton:Button
    private lateinit var privacyButton:Button//

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("UserData", Context.MODE_PRIVATE)

        // Initialize views
        profileImageView = findViewById(R.id.profileImageView)
        changeProfileButton = findViewById(R.id.changeProfileButton)
        nameEditText = findViewById(R.id.nameEditText)
        saveButton = findViewById(R.id.saveButton)
        privacyButton=findViewById(R.id.button2)  ////1

        // Load saved data
        val profilePic = loadProfilePic()
        val name = loadName()
        profileImageView.setImageBitmap(profilePic)
        nameEditText.setText(name)

        // Set click listeners
        changeProfileButton.setOnClickListener {
            openGallery()
        }

        saveButton.setOnClickListener {
            saveData()
        }
        backButton=findViewById(R.id.button4)
        backButton.setOnClickListener {
            finish()   // Finish the current activity when the back button is clicked
        }
        privacyButton.setOnClickListener {
            val intent = Intent(this, PrivacyPolicyActivity::class.java)
            startActivity(intent)
        }

    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK) {
            val imageUri = data?.data
            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, imageUri)
            profileImageView.setImageBitmap(bitmap)
        }
    }

    private fun saveData() {
        val name = nameEditText.text.toString()
        saveProfilePic(profileImageView.drawable.toBitmap())
        saveName(name)
    }

    private fun saveProfilePic(bitmap: Bitmap) {
        val editor = sharedPreferences.edit()
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        editor.putString("profilePic", Base64.encodeToString(byteArray, Base64.DEFAULT))
        editor.apply()
    }

    private fun loadProfilePic(): Bitmap? {
        val encodedString = sharedPreferences.getString("profilePic", null)
        return if (encodedString != null) {
            val byteArray = Base64.decode(encodedString, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
        } else {
            null
        }
    }

    private fun saveName(name: String) {
        val editor = sharedPreferences.edit()
        editor.putString("name", name)
        editor.apply()
    }

    private fun loadName(): String? {
        return sharedPreferences.getString("name", "")
    }

    companion object {
        private const val GALLERY_REQUEST_CODE = 100
    }
}
