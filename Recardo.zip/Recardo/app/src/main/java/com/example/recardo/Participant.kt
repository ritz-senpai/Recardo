package com.example.recardo

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import java.io.ByteArrayOutputStream

data class Participant(val name: String, val profilePic: Bitmap?) {

    companion object {
        fun encodeToString(participants: MutableList<Participant>): String {
            val encodedParticipants = mutableListOf<String>()
            participants.forEach { participant ->
                val outputStream = ByteArrayOutputStream()
                participant.profilePic?.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                val byteArray = outputStream.toByteArray()
                val encodedImage = Base64.encodeToString(byteArray, Base64.DEFAULT)
                encodedParticipants.add("${participant.name}|$encodedImage")
            }
            return encodedParticipants.joinToString(separator = ",")
        }

        fun decodeFromString(encodedParticipantsString: String): MutableList<Participant> {
            val decodedParticipants = mutableListOf<Participant>()
            val encodedParticipants = encodedParticipantsString.split(",")
            encodedParticipants.forEach { encodedParticipant ->
                val participantInfo = encodedParticipant.split("|")
                if (participantInfo.size == 2) { // Ensure that the participantInfo array has two elements
                    val name = participantInfo[0]
                    val profilePicString = participantInfo[1]
                    val profilePicByteArray = Base64.decode(profilePicString, Base64.DEFAULT)
                    val profilePic = BitmapFactory.decodeByteArray(profilePicByteArray, 0, profilePicByteArray.size)
                    decodedParticipants.add(Participant(name, profilePic))
                } else {
                    // Log or handle the case where the format is incorrect
                    // For example:
                     Log.e("Decode", "Invalid format for participant: $encodedParticipant")
                }
            }
            return decodedParticipants
        }
    }
}
