package com.example.recardo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson

class Activity2 : AppCompatActivity() {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var profilePicImageView: ImageView
    private lateinit var participantNameTextView: TextView
    private lateinit var totalAmountTextView: TextView
    private lateinit var amountEditText: EditText
    private lateinit var noteEditText: EditText
    private lateinit var debitButton: Button
    private lateinit var creditButton: Button
    private lateinit var historyButton: Button
    private val transactionList = mutableListOf<Transaction>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)

        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("TransactionHistory", Context.MODE_PRIVATE)

        // Initialize views
        profilePicImageView = findViewById(R.id.profilePicImageView)
        participantNameTextView = findViewById(R.id.participantNameTextView)
        totalAmountTextView = findViewById(R.id.totalAmountTextView)
        amountEditText = findViewById(R.id.amountEditText)
        noteEditText = findViewById(R.id.noteEditText)
        debitButton = findViewById(R.id.debitButton)
        creditButton = findViewById(R.id.creditButton)
        historyButton = findViewById(R.id.historyButton)

        // Retrieve participant's name and profile picture from intent extras
        val participantName = intent.getStringExtra("participantName")
        //  val profilePic = intent.getParcelableExtra<Bitmap>("participantProfilePic")  initial
        val profilePicByteArray = intent.getByteArrayExtra("participantProfilePic") /// change (2)
        val profilePic = profilePicByteArray?.toBitmap()  ///change 3
        loadTransactionHistory(participantName)

        // Set participant's name and profile picture
        participantNameTextView.text = participantName
        // profilePicImageView.setImageBitmap(profilePic) -- initially
        profilePic?.let { profilePicImageView.setImageBitmap(it) }
        profilePic?.let { profilePicImageView.setImageBitmap(it) }

        // Initialize total amount
        val initialAmount = sharedPreferences.getFloat("totalAmount_$participantName", 0f)
        totalAmountTextView.text = "Total Amount: $initialAmount"

        // Set up click listeners for debit, credit, and history buttons
        debitButton.setOnClickListener {
            handleTransaction(-1)
        }

        creditButton.setOnClickListener {
            handleTransaction(1)
        }

        historyButton.setOnClickListener {
            val intent = Intent(this, Activity3::class.java)
            intent.putExtra("participantName", participantName)
            // Convert the profile picture bitmap to a byte array
            val profilePicByteArray = profilePic?.toByteArray()
            // Pass the profile picture byte array as an extra to Activity3
            intent.putExtra("participantProfilePic", profilePicByteArray)
            startActivity(intent)
        }
    }

    private fun handleTransaction(sign: Int) {
        val amountString = amountEditText.text.toString()
        val note = noteEditText.text.toString()

        if (amountString.isBlank()) {
            // Show error message if amount is empty
            Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountString.toFloatOrNull()

        if (amount == null || amount <= 0) {
            // Show error message if amount is not a valid positive number
            Toast.makeText(this, "Please enter a valid positive amount", Toast.LENGTH_SHORT).show()
            return
        }

        if (note.isBlank()) {
            // Show error message if note is empty
            Toast.makeText(this, "Please enter a note", Toast.LENGTH_SHORT).show()
            return
        }

        val participantName = participantNameTextView.text.toString()
        val currentAmount = sharedPreferences.getFloat("totalAmount_$participantName", 0f)
        val updatedAmount = currentAmount + sign * amount

        // Update total amount
        sharedPreferences.edit().putFloat("totalAmount_$participantName", updatedAmount).apply()
        totalAmountTextView.text = "Total Amount: $updatedAmount"

        val transactionType = if (sign < 0) "Debit" else "Credit" ///1

        // Save transaction details
        saveTransaction(participantName, amount, note ,  transactionType) ///1 added new para
        amountEditText.setText("")
        noteEditText.setText("")

    }

    private fun saveTransaction(participantName: String, amount: Float, note: String , transactionType: String) { ///2. add new para
        // Get current timestamp
        val timestamp = System.currentTimeMillis()

        // Get the key for this participant's transaction history in SharedPreferences
        val transactionKey = "transactionHistory_$participantName"

        // Retrieve the existing transaction history for this participant
        val transactionHistoryJson = sharedPreferences.getString(transactionKey, "")
        // Determine the transaction type
       // val transactionType = if (amount < 0) "Debit" else "Credit"     ////1

        // Create a new transaction object
        val newTransaction = Transaction(timestamp, amount, note,transactionType)  ///2 added new pararmeter , transactionType.

        // Convert the new transaction to JSON format
        val newTransactionJson = Gson().toJson(newTransaction)

        // Combine the new transaction with the existing transaction history
        val updatedTransactionHistoryJson = if (transactionHistoryJson.isNullOrEmpty()) {
            "[$newTransactionJson]" // If there's no existing history, create a new array with the new transaction
        } else {
            val existingTransactions = Gson().fromJson(transactionHistoryJson, Array<Transaction>::class.java)
            val updatedTransactions = existingTransactions.toMutableList().apply { add(newTransaction) }
            Gson().toJson(updatedTransactions) // If there's existing history, add the new transaction to the array
        }

        // Save the updated transaction history back to SharedPreferences
        sharedPreferences.edit().putString(transactionKey, updatedTransactionHistoryJson).apply()
    }
    private fun loadTransactionHistory(participantName: String?) {
        participantName?.let { name ->
            val transactionKey = "transactionHistory_$name"
            val transactionHistoryJson = sharedPreferences.getString(transactionKey, "")

            if (!transactionHistoryJson.isNullOrEmpty()) {
                val transactions = Gson().fromJson(transactionHistoryJson, Array<Transaction>::class.java)
                transactionList.addAll(transactions)
            }
        }
    }

}
