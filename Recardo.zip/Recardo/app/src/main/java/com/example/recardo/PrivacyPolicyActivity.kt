package com.example.recardo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.widget.Toolbar

class PrivacyPolicyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_policy)

        // Find the Toolbar by its ID
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = ""


        // Set the Toolbar as ActionBar
        setSupportActionBar(toolbar)
    }
}