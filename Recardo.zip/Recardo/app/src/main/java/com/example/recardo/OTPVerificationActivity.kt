package com.example.recardo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button


class OTPVerificationActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otpverification)
        // Initialize SharedPreferences
        sharedPreferences = getSharedPreferences("login_pref", Context.MODE_PRIVATE)


        val verifyButton: Button = findViewById(R.id.verifyButton)
        verifyButton.setOnClickListener {
            // Fake OTP verification process for demonstration
            // Set the user as logged in
            setLoggedIn(true)
            // Start MainActivity
            startMainActivity()
        }
    }
    private fun setLoggedIn(isLoggedIn: Boolean) {
        sharedPreferences.edit().putBoolean("is_logged_in", isLoggedIn).apply()
    }
    private fun startMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Close the OTPVerificationActivity
    }
}