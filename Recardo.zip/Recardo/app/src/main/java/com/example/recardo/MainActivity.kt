package com.example.recardo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity(), AddParticipantDialogFragment.AddParticipantDialogListener {

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var participantList: MutableList<Participant>
    private lateinit var listView: ListView
    private lateinit var adapter: ParticipantAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ///Login process code
        sharedPreferences = getSharedPreferences("login_pref", Context.MODE_PRIVATE)
        // Check if the user is logged in
        val isLoggedIn = sharedPreferences.getBoolean("is_logged_in", false)
        if (!isLoggedIn) {
            // If not logged in, start the LoginActivity
            startLoginActivity()
        }


        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        participantList = Participant.decodeFromString(sharedPreferences.getString("participantList", "") ?: "")
        adapter = ParticipantAdapter(this, participantList)
        listView = findViewById(R.id.listViewParticipants)
        listView.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fab_add_participant).setOnClickListener {
            val dialog = AddParticipantDialogFragment()
            dialog.show(supportFragmentManager, "AddParticipantDialogFragment")
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val participant = participantList[position]
            val intent = Intent(this, Activity2::class.java).apply {
                putExtra("participantName", participant.name)
                putExtra("participantProfilePic", participant.profilePic?.toByteArray()) /// change from .profilePic (1)
                // Add any other participant details here if needed
            }
            startActivity(intent)
        }
        ///code for setting button
        val settingsButton = findViewById<ImageButton>(R.id.imageButton)
        settingsButton.setOnClickListener {
            val intent = Intent(this, settingActivity::class.java)
            startActivity(intent)
        }
        ///end of setting button

    }
    ///login code
    private fun startLoginActivity() {
        val intent = Intent(this, loginActivity::class.java)
        startActivity(intent)
        finish() // Close the MainActivity
    }

    override fun onParticipantAdded(participant: Participant) {
        participantList.add(participant)
        adapter.notifyDataSetChanged()

        val editor = sharedPreferences.edit()
        editor.putString("participantList", Participant.encodeToString(participantList))
        editor.apply()
    }

    class ParticipantAdapter(context: Context, participants: MutableList<Participant>) :
        ArrayAdapter<Participant>(context, 0, participants) {

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            var itemView = convertView
            if (itemView == null) {
                itemView = LayoutInflater.from(context).inflate(R.layout.item_participant, parent, false)
            }

            val participant = getItem(position)

            // Display participant's name
            val tvParticipantName = itemView!!.findViewById<TextView>(R.id.tvParticipantName)
            tvParticipantName.text = participant?.name

            // Display participant's profile picture
            val ivProfilePic = itemView.findViewById<ImageView>(R.id.ivProfilePic)
            participant?.profilePic?.let {
                ivProfilePic.setImageBitmap(it)
            } ?: run {
                // If profile picture is null, set a default image
                ivProfilePic.setImageResource(R.drawable.ic_default_profile_pic)
            }

            return itemView
        }
    }
}

